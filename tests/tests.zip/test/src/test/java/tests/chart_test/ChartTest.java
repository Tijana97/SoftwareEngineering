package tests.chart_test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.Select;

class ChartTest {

	private static WebDriver webDriver;
	private static String baseUrl;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:/Users/EC/Desktop/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		
		options.addArguments("--start-maximized");
		options.addArguments("--remote-allow-origins=*");
		
		webDriver = new ChromeDriver(options);
		baseUrl = "http://209.38.206.111/SoftwareEngineering/login.html";
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		webDriver.quit();
	}

	@Test
	void test() throws InterruptedException {
		webDriver.get(baseUrl);
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/form/div[1]/input")).sendKeys("dzanin.masic@stu.ibu.edu.ba");
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/form/div[2]/input")).sendKeys("dzanin");
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/form/button")).click();
		
		Thread.sleep(3000);
		String url = webDriver.getCurrentUrl();
		assertEquals("http://209.38.206.111/SoftwareEngineering/index.html", url);
		
		String buttonColor = webDriver.findElement(By.xpath("/html/body/main/div/div/div[1]/div/button")).getCssValue("background-color");
		String colorToHex = Color.fromString(buttonColor).asHex();
		assertEquals("#6c757d", colorToHex);
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/div[1]/div/button")).click();
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/div/form/button[2]")).click();
		Thread.sleep(3000);
		
		String chartTitle = webDriver.findElement(By.xpath("/html/body/main/div/div/div[1]/form/button")).getText();
		assertEquals(true, chartTitle.contains("Home"));
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/div[1]/form/button")).click();
		Thread.sleep(3000);
	}
}
