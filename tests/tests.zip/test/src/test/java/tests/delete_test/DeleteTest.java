package tests.delete_test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.Select;

class DeleteTest {

	private static WebDriver webDriver;
	private static String baseUrl;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:/Users/EC/Desktop/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		
		options.addArguments("--start-maximized");
		options.addArguments("--remote-allow-origins=*");
		
		webDriver = new ChromeDriver(options);
		baseUrl = "http://209.38.206.111/SoftwareEngineering/login.html";
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		webDriver.quit();
	}

	@Test
	void test() throws InterruptedException {
		webDriver.get(baseUrl);
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/form/div[1]/input")).sendKeys("dzanin.masic@stu.ibu.edu.ba");
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/form/div[2]/input")).sendKeys("dzanin");
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/form/button")).click();
		
		Thread.sleep(3000);
		String url = webDriver.getCurrentUrl();
		assertEquals("http://209.38.206.111/SoftwareEngineering/index.html", url);
		
		String buttonFontWeight = webDriver.findElement(By.xpath("/html/body/main/div/div/div[2]/div/div/button[2]")).getCssValue("font-weight");
		assertEquals("400", buttonFontWeight);
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/div[2]/div/div/button[2]")).click();
		Thread.sleep(3000);
		
		String modalTitle = webDriver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/h5")).getText();
		assertEquals("Modal title", modalTitle);
		
		webDriver.findElement(By.xpath("/html/body/div[2]/div/div/div[3]/button[2]")).click();
		Thread.sleep(3000);
	}
}
