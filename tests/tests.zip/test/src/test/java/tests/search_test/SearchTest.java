package tests.search_test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.Color;

class SearchTest {

	private static WebDriver webDriver;
	private static String baseUrl;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:/Users/EC/Desktop/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		
		options.addArguments("--start-maximized");
		options.addArguments("--remote-allow-origins=*");
		
		webDriver = new ChromeDriver(options);
		baseUrl = "http://209.38.206.111/SoftwareEngineering/login.html";
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		webDriver.quit();
	}

	@Test
	void test() throws InterruptedException {
		webDriver.get(baseUrl);
		Thread.sleep(3000);
		
		String buttonColor = webDriver.findElement(By.xpath("/html/body/main/div/div/form/button")).getCssValue("background-color");
		String colorToHex = Color.fromString(buttonColor).asHex();
		assertEquals("#0d6efd", colorToHex);
		Thread.sleep(1000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/form/div[1]/input")).sendKeys("dzanin.masic@stu.ibu.edu.ba");
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/form/div[2]/input")).sendKeys("dzanin");
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("/html/body/main/div/div/form/button")).click();
		Thread.sleep(3000);
		String url = webDriver.getCurrentUrl();
		assertEquals("http://209.38.206.111/SoftwareEngineering/index.html", url);
		
		webDriver.findElement(By.id("search-material")).sendKeys("polar");
		Thread.sleep(3000);
		webDriver.findElement(By.xpath("/html/body/header/nav/div/div/form[1]/div[2]/button")).click();
		Thread.sleep(3000);
		
		String materialType = webDriver.findElement(By.xpath("/html/body/main/div/div/div/div/div/h5")).getText();
		assertEquals("Polar", materialType);
		
		Thread.sleep(3000);
		webDriver.findElement(By.xpath("/html/body/main/div/div/form/button")).click();
		
		Thread.sleep(3000);
		
		String addColorButton = webDriver.findElement(By.xpath("/html/body/header/nav/div/div/ul/li[2]/button")).getCssValue("border-color");
		String addColorToHex = Color.fromString(addColorButton).asHex();
		assertEquals("#198754", addColorToHex);
		Thread.sleep(1000);
		
		webDriver.findElement(By.xpath("/html/body/header/nav/div/div/form[2]/button")).click();
		Thread.sleep(1000);
		
		String url2 = webDriver.getCurrentUrl();
		assertEquals("http://209.38.206.111/SoftwareEngineering/login.html", url2);
	}
}
